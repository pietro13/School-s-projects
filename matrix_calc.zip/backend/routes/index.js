var express = require('express');
var router = express.Router();
const  math  = require('mathjs');



///////////////////////////////////////////text = nazov////////////////////////////////////////////////////
router.get('/add_name/:name', function(req, res, next) {
  req.app.locals.data['name'] = req.params['name'];
  res.send("");
});
///////////////////////////////////////////text = nazov je prazdny////////////////////////////////////////////////////
router.get('/add_name/', function(req, res, next) {
  req.app.locals.data['name'] = '';
  res.send("");
});
///////////////////////////////////////////text = popis////////////////////////////////////////////////////
router.get('/add_instruct/:text', function(req, res, next) {
  req.app.locals.data['instruct'] = req.params['text'];
  res.send("");
});
///////////////////////////////////////////text = popis je prazdny////////////////////////////////////////////////////
router.get('/add_instruct/', function(req, res, next) {
  req.app.locals.data['instruct'] = '';
  res.send("");
});



// vyziadanie dat
router.get('/get_data', function(req, res, next) {
  console.log(req.app.locals.data);
  res.send(req.app.locals.data);
});


//vkladan novu maticu
router.get('/add_new_matrix', function(req, res, next) {
  //pridanie za aktivnu maticu inak na koniec retazca
  if(req.app.locals.data['active_matrix'] > -1) {// aktivna matica existuje
    req.app.locals.data['all_matrix'].splice(req.app.locals.data['active_matrix'] + 1, 0, [['']]);
    req.app.locals.data['all_oper'].splice(req.app.locals.data['active_matrix'] + 1, 0, '');
    req.app.locals.data['active_matrix'] += 1;
    req.app.locals.data['active_y'] = 0;
    req.app.locals.data['active_x'] = 0;
  }
  else
  {// aktivna matica neexistuje
    req.app.locals.data['all_matrix'].push([['']]);
    req.app.locals.data['all_oper'].push('');
    req.app.locals.data['active_matrix'] = req.app.locals.data['all_matrix'].length -1;
    req.app.locals.data['active_y'] = 0;
    req.app.locals.data['active_x'] = 0;
  }
  res.send(req.app.locals.data);
});

//vkladan novu operaciu
router.get('/add_new_oper/:oper', function(req, res, next) {
  req.app.locals.data['all_oper'][req.app.locals.data['active_matrix']] = req.params['oper'];
  res.send(req.app.locals.data);


});


/////////////////////////////////////TOOLbar///////////////////////////////////////////////////////////

/////////////////////////////////////odstranenie matice///////////////////////////////////////////////////////////
router.get('/del_matrix', function(req, res, next) {

  if(req.app.locals.data['active_matrix'] > -1) {
    req.app.locals.data['all_matrix'].splice(req.app.locals.data['active_matrix'], 1);
    req.app.locals.data['all_oper'].splice(req.app.locals.data['active_matrix'], 1);
    req.app.locals.data['active_matrix'] = -1;
    req.app.locals.data['active_y'] = -1;
    req.app.locals.data['active_x'] = -1;
  }
  res.send(req.app.locals.data);


});

/////////////////////////////////////odstranenie operacie///////////////////////////////////////////////////////////
router.get('/del_oper', function(req, res, next) {

  req.app.locals.data['all_oper'][req.app.locals.data['active_matrix']] = '';
  res.send(req.app.locals.data);


});

/////////////////////////////////////transponovat maticu///////////////////////////////////////////////////////////
router.get('/trans_matrix', function(req, res, next) {

  var actual = req.app.locals.data['all_matrix'][req.app.locals.data['active_matrix']];
  var trans = [];
  for(var j = 0; j < actual[0].length;j++ )
  {
    var row = []
    for(var i = 0; i < actual.length;i++ )
    {
      row.push(actual[i][j]);
    }
    trans.push(row);
  }
  req.app.locals.data['all_matrix'][req.app.locals.data['active_matrix']] = trans;
  req.app.locals.data['active_y'] = 0;
  req.app.locals.data['active_x'] = 0;
  req.app.locals.data['caret'] = 0;


  res.send(req.app.locals.data);


});

/////////////////////////////////////dropnutie matice///////////////////////////////////////////////////////////
router.get('/drop_to_matrix/:array', function(req, res, next) {

  var array = JSON.parse(req.params['array']);

  req.app.locals.data['all_matrix'][req.app.locals.data['active_matrix']] = array;

  res.send(req.app.locals.data);


});




//////////////////////////////////////////////MatrixController//////////////////////////////////////////////////////////

/////////////////////////////////////nastvenie umiestenia kurzoru///////////////////////////////////////////////////////////
router.get('/set_active_cell/:z/:y/:x/:caret', function(req, res, next) {
  req.app.locals.data['active_matrix'] = parseInt(req.params['z']);
  req.app.locals.data['active_y'] = parseInt(req.params['y']);
  req.app.locals.data['active_x'] = parseInt(req.params['x']);
  req.app.locals.data['caret'] = parseInt(req.params['caret']);
  res.send(req.app.locals.data);

});

/////////////////////////////////////nastvenie hodnoty v bunke aktivnej matice///////////////////////////////////////////////////////////
router.get('/set_value_cell/:z/:y/:x/:value', function(req, res, next) {
  req.app.locals.data['active_matrix'] = parseInt(req.params['z']);
  req.app.locals.data['active_y'] = parseInt(req.params['y']);
  req.app.locals.data['active_x'] = parseInt(req.params['x']);
  req.app.locals.data['all_matrix'][req.params['z']][req.params['y']][req.params['x']] = req.params['value'];
  res.send(req.app.locals.data);

});


/////////////////////////////////////pridanie riadkov v matici///////////////////////////////////////////////////////////
router.get('/add_row/:val', function(req, res, next) {
  if(req.app.locals.data['all_matrix'][req.app.locals.data['active_matrix']].length -1 < req.params['val'] ) {
    var newColumn = new Array(req.app.locals.data['all_matrix'][req.app.locals.data['active_matrix']][0].length);
    for (var i = 0; i < newColumn.length; i++) {
      newColumn[i] = ''
    }


    req.app.locals.data['all_matrix'][req.app.locals.data['active_matrix']].push(newColumn);
    console.log(req.app.locals.data);
  }
  res.send(req.app.locals.data);


});

/////////////////////////////////////odstranenie riadkov v matici///////////////////////////////////////////////////////////
router.get('/del_row/:val', function(req, res, next) {
  if(req.app.locals.data['all_matrix'][req.app.locals.data['active_matrix']].length -1 > req.params['val'] ) {
    if (req.app.locals.data['all_matrix'][req.app.locals.data['active_matrix']].length - 1 <= req.app.locals.data['active_y']) {
      req.app.locals.data['active_y'] = req.app.locals.data['all_matrix'][req.app.locals.data['active_matrix']].length - 2;
    }

    req.app.locals.data['all_matrix'][req.app.locals.data['active_matrix']].pop();
  }
  res.send(req.app.locals.data);


});

/////////////////////////////////////pridanie stlpcov v matici///////////////////////////////////////////////////////////
router.get('/add_column/:val', function(req, res, next) {
  if(req.app.locals.data['all_matrix'][req.app.locals.data['active_matrix']][0].length -1 < req.params['val'] ) {
    var newColumn = new Array(req.app.locals.data['all_matrix'][req.app.locals.data['active_matrix']][0].length);
    var height = req.app.locals.data['all_matrix'][req.app.locals.data['active_matrix']].length;
    for (var i = 0; i < height; i++) {
      req.app.locals.data['all_matrix'][req.app.locals.data['active_matrix']][i].push("");
    }


    //req.app.locals.data['all_matrix'][req.app.locals.data['active_matrix']].push(newColumn);
    console.log(req.app.locals.data);
  }
  res.send(req.app.locals.data);


});

/////////////////////////////////////odstranenie stlpcov v matici///////////////////////////////////////////////////////////
router.get('/del_column/:val', function(req, res, next) {
  if(req.app.locals.data['all_matrix'][req.app.locals.data['active_matrix']][0].length -1 > req.params['val'] ) {
    if (req.app.locals.data['all_matrix'][req.app.locals.data['active_matrix']].length - 1 <= req.app.locals.data['active_y']) { //aktivna bunka v odstranovanom stlpci
      req.app.locals.data['active_y'] = req.app.locals.data['all_matrix'][req.app.locals.data['active_matrix']].length - 2;
    }
    var height = req.app.locals.data['all_matrix'][req.app.locals.data['active_matrix']].length;
    console.log(height);
    for (var i = 0; i < height; i++) {
      console.log("in" + i);
      req.app.locals.data['all_matrix'][req.app.locals.data['active_matrix']][i].pop();
    }
  }
  res.send(req.app.locals.data);


});


/////////////////////////////////////zmena hodnoty v bunke aktivnej matici///////////////////////////////////////////////////////////
router.get('/set_value_cell/:z/:y/:x/:value/:oper/:caret', function(req, res, next) {
  req.app.locals.data['active_matrix'] = parseInt(req.params['z']);
  req.app.locals.data['active_y'] = parseInt(req.params['y']);
  req.app.locals.data['active_x'] = parseInt(req.params['x']);
  if(req.params['caret'] == "panel") {
    if (req.params['oper'] == "+")
      req.app.locals.data['caret'] += 1;
    else
      req.app.locals.data['caret'] -= 1;
  }
    else
      req.app.locals.data['caret'] = parseInt(req.params['caret']);
  req.app.locals.data['all_matrix'][req.params['z']][req.params['y']][req.params['x']] = req.params['value'];
  res.send(req.app.locals.data);

});

/////////////////////////////////////zmena na prazdnu hodnotu v bunke aktivnej matici///////////////////////////////////////////////////////////
router.get('/set_value_cell/:z/:y/:x//:oper/:caret', function(req, res, next) {
  req.app.locals.data['active_matrix'] = parseInt(req.params['z']);
  req.app.locals.data['active_y'] = parseInt(req.params['y']);
  req.app.locals.data['active_x'] = parseInt(req.params['x']);
  if(req.params['caret'] != "panel")
  req.app.locals.data['caret'] = parseInt(req.params['caret']);
  else
    req.app.locals.data['caret'] -= 1;
  req.app.locals.data['all_matrix'][req.params['z']][req.params['y']][req.params['x']] = '';
  res.send(req.app.locals.data);

});

/////////////////////////////////////vypocet matic///////////////////////////////////////////////////////////
router.get('/result/', function(req, res, next) {
  // premenna "a" vujadruje spravnost retazca
  var calculator = JSON.parse(JSON.stringify(req.app.locals.data['all_matrix']));
  var calc_oper = JSON.parse(JSON.stringify(req.app.locals.data['all_oper']));
  var postup = [];
  var a = true;
  // operacie medzi vsetkymi maticami
  for(var i = 0; i < calc_oper.length - 1; i++  ) {

    if(calc_oper[i] == '')
    {
      a = false;
    }
  }
  //na konci retazca je matica a nie operacia
  if(calc_oper[calc_oper.length - 1] != '')
  {
    a=false
  }

  while(calculator.length != 1 && a)
  {
      // prejdenie retazca a vypocet matic s * operaciou
      for(var i = 0; i < calc_oper.length; i++  )
      {
        if(calc_oper[i] == "*" )
        {
          var val = math.multiply(calculator[i],calculator[i+1]);
          var array =  [calculator[i],calc_oper[i],calculator[i+1],val];
          postup.push(array);
          //nahranie matic a operacie vysledkom
          calculator.splice(i, 2,val);
          calc_oper.splice(i, 1);
          console.log(calculator);
        }
      }
      // vypocet matic s operaciami + a -
    for(var i = 0; i < calc_oper.length; i++  )
    {
      if(calc_oper[i] == "+" )
      {
        var val = math.add(calculator[i],calculator[i+1]);
        var array =  [calculator[i],calc_oper[i],calculator[i+1],val];
        postup.push(array);
        calculator.splice(i, 2,val);
        calc_oper.splice(i, 1);
        console.log(calculator);
      }
      if(calc_oper[i] == "-" )
      {
        var val = math.subtract(calculator[i],calculator[i+1]);
        var array =  [calculator[i],calc_oper[i],calculator[i+1],val];
        postup.push(array);
        calculator.splice(i, 2,val);
        calc_oper.splice(i, 1);
        console.log(calculator);
      }
    }

  }
  // ulozenie postupu a vypoctu
  if(a) {
    req.app.locals.data['process'] = postup;
    req.app.locals.data['result'] = calculator;
  }
  else
  {
    req.app.locals.data['process'] = [];
    req.app.locals.data['result'] = [];
  }

  res.send(req.app.locals.data);
});




module.exports = router;
