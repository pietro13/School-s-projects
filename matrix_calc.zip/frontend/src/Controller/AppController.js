


import React from "react";



var server = 'http://127.0.0.1:9000';



export async function get_data()
{


    const res = await fetch(new URL("/get_data",server));
        const data = await res.json();
        return data;

};


export async function add_name(e)
{

    fetch(new URL("/add_name/"+ e.target.value, server))

};




export async function add_instruct(e)
{

    fetch(new URL("/add_instruct/"+ e.target.value, server))

};









