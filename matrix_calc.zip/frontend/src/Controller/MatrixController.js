import * as AppController from "./AppController";
import React from "react";
import ReactDOM from "react-dom";
import CalcDisplay from "../View/CalcDisplay";
import { active } from "../Controller/KeyboardController"

var server = 'http://127.0.0.1:9000';

//aktivovanie bunky matice

export async function active_cell(e,z,y,x)
{

        var caret = getCursorPosition(e.nativeEvent.srcElement);

        fetch(new URL("/set_active_cell/" + z + "/" + y +"/" + x +"/" + caret, server))
            .then(res => res.json())
            .then(res => {

                        ReactDOM.render(
                            <React.StrictMode>
                                <CalcDisplay Data = {res}/>
                            </React.StrictMode>,
                            document.getElementById('calc_display')
                    );
                var el = document.getElementById("celltrue");

                el.setSelectionRange(res['caret'], res['caret']);
                }, (err) => {
                    console.log(err);
                }
            );



}

// inspiracia z https://stackoverflow.com/questions/19755633/detect-when-cursor-position-inside-input-change-in-jquery
//ziskanie polohu kurzoru
function getCursorPosition(element) {
    var el = element;
    var pos = 0;
    if ('selectionStart' in el) {
        pos = el.selectionStart;
    } else if ('selection' in document) {
        el.focus();
        var Sel = document.selection.createRange();
        var SelLength = document.selection.createRange().text.length;
        Sel.moveStart('character', -el.value.length);
        pos = Sel.text.length - SelLength;
    }
    return pos;
}

// nastavenie hodnoty na aktivnej bunke
export async function set_value_cell(e,z,y,x,caret)
{
    var value = e.target.value;

    var caret = getCursorPosition(e.nativeEvent.srcElement);

    if(value == ''){value = ''}
    var data = await AppController.get_data();

    if(((value.match("^-?[0-9]?$") != null ||
        value.match("^-?0\\.[0-9]*$") != null ||
        value.match("^-?[1-9][0-9]*$") != null ||
        value.match("^-?[1-9][0-9]*\\.[0-9]*$") != null ) && !active) ||
        (value.match("^[0-9]?$") != null ||
            value.match("^0\\.[0-9]*$") != null ||
            value.match("^[1-9][0-9]*$") != null ||
            value.match("^[1-9][0-9]*\\.[0-9]*$") != null ) ) {

        fetch(new URL("/set_value_cell/" + z + "/" + y + "/" + x + "/" + value +"/" + "+" + "/" + caret, server))
            .then(res => res.json())
            .then(res => {
                ReactDOM.render(
                    <React.StrictMode>
                        <CalcDisplay Data = {res}/>
                    </React.StrictMode>,
                    document.getElementById('calc_display')
                    );
                var el = document.getElementById("celltrue");

                el.setSelectionRange(res['caret'], res['caret']);
                }, (err) => {
                    console.log(err);
                }
            );

    }

}

//nastavenie hodnoty pomocou panelu
export async function set_value_cell_panel(value)
{

    var data = await AppController.get_data();
    if(data['active_matrix'] > -1 && data['active_y'] > -1 && data['active_x'] > -1) {
        var newval = [data['all_matrix'][data['active_matrix']][data['active_y']][data['active_x']].slice(0, data['caret']), value, data['all_matrix'][data['active_matrix']][data['active_y']][data['active_x']].slice(data['caret'])].join('');
        if (((newval.match("^-?[0-9]?$") != null ||
            newval.match("^-?0\\.[0-9]*$") != null ||
            newval.match("^-?[1-9][0-9]*$") != null ||
            newval.match("^-?[1-9][0-9]*\\.[0-9]*$") != null) && !active) ||
            (newval.match("^[0-9]?$") != null ||
                newval.match("^0\\.[0-9]*$") != null ||
                newval.match("^[1-9][0-9]*$") != null ||
                newval.match("^[1-9][0-9]*\\.[0-9]*$") != null)) {

            fetch(new URL("/set_value_cell/" + data['active_matrix'] + "/" + data['active_y'] + "/" + data['active_x'] + "/" + newval + "/" + "+" + "/" + "panel", server))
                .then(res => res.json())
                .then(res => {
                        ReactDOM.render(
                            <React.StrictMode>
                                <CalcDisplay Data={res}/>
                            </React.StrictMode>,
                            document.getElementById('calc_display')
                        );
                    var el = document.getElementById("celltrue");
                    el.focus();
                        el.setSelectionRange(res['caret'], res['caret']);
                    }, (err) => {
                        console.log(err);
                    }
                );

        }
    }

}

export async function del_value_cell_panel()
{

    var data = await AppController.get_data();

    if(data['active_matrix'] > -1 && data['active_y'] > -1 && data['active_x'] > -1) {

        var newval = data['all_matrix'][data['active_matrix']][data['active_y']][data['active_x']];
        if(newval)
        {
            console.log(data['caret']);
            if(data['caret']>0) {
                newval = newval.slice(0, data['caret'] - 1) + newval.slice(data['caret']);

                if (((newval.match("^-?[0-9]?$") != null ||
                    newval.match("^-?0\\.[0-9]*$") != null ||
                    newval.match("^-?[1-9][0-9]*$") != null ||
                    newval.match("^-?[1-9][0-9]*\\.[0-9]*$") != null) && !active) ||
                    (newval.match("^[0-9]?$") != null ||
                        newval.match("^0\\.[0-9]*$") != null ||
                        newval.match("^[1-9][0-9]*$") != null ||
                        newval.match("^$") != null ||
                        newval.match("^[1-9][0-9]*\\.[0-9]*$") != null)) {

                    fetch(new URL("/set_value_cell/" + data['active_matrix'] + "/" + data['active_y'] + "/" + data['active_x'] + "/" + newval + "/" + "-" + "/" + "panel", server))
                        .then(res => res.json())
                        .then(res => {
                                ReactDOM.render(
                                    <React.StrictMode>
                                        <CalcDisplay Data={res}/>
                                    </React.StrictMode>,
                                    document.getElementById('calc_display')
                                );
                            var el = document.getElementById("celltrue");
                            el.focus();
                            el.setSelectionRange(res['caret'], res['caret']);

                            }, (err) => {
                                console.log(err);
                            }
                        );

                }
            }
        }
    }

}

//zmena poctu riadkov matice
export async function change_rows(value , change) {

    if(change) {
        var data = await AppController.get_data();

        console.log(data['all_matrix'][data['active_matrix']].length + "|" + value);
        //zvacsenie poctu
        if (data['all_matrix'][data['active_matrix']].length - 1 < value) {
            fetch(new URL("/add_row/" + value, server))
                .then(res => res.json())
                .then(res => {
                        ReactDOM.render(
                            <React.StrictMode>
                                <CalcDisplay Data={res}/>
                            </React.StrictMode>,
                            document.getElementById('calc_display')
                        );

                    }, (err) => {
                        console.log(err);
                    }
                );
        } //zmensenie poctu
        else if (data['all_matrix'][data['active_matrix']].length - 1 > value) {
            fetch(new URL("/del_row/" + value, server))
                .then(res => res.json())
                .then(res => {
                        ReactDOM.render(
                            <React.StrictMode>
                                <CalcDisplay Data={res}/>
                            </React.StrictMode>,
                            document.getElementById('calc_display')
                        );
                    }, (err) => {
                        console.log(err);
                    }
                );
        }
    }

}

//zmena postu stlpcou matice
export async function change_columns(value , change) {

    if(change) {
        var data = await AppController.get_data();

        console.log(data['all_matrix'][data['active_matrix']].length + "|" + value);
        //zvacsenie poctu
        if (data['all_matrix'][data['active_matrix']][0].length - 1 < value) {
            fetch(new URL("/add_column/" + value, server))
                .then(res => res.json())
                .then(res => {
                        ReactDOM.render(
                            <React.StrictMode>
                                <CalcDisplay Data={res}/>
                            </React.StrictMode>,
                            document.getElementById('calc_display')
                        );
                    }, (err) => {
                        console.log(err);
                    }
                );

        } //znizenie poctu
        else if (data['all_matrix'][data['active_matrix']][0].length - 1 > value) {
            fetch(new URL("/del_column/" + value, server))
                .then(res => res.json())
                .then(res => {
                        ReactDOM.render(
                            <React.StrictMode>
                                <CalcDisplay Data={res}/>
                            </React.StrictMode>,
                            document.getElementById('calc_display')
                        );
                    }, (err) => {
                        console.log(err);
                    }
                );
        }
    }

}


