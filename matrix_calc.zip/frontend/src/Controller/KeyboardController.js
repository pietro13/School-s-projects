import * as AppController from "./AppController";
import React from "react";
import ReactDOM from "react-dom";

import CalcDisplay from "../View/CalcDisplay";
import * as CalcController from "../Controller/CalcController"


var server = 'http://127.0.0.1:9000';

export var active = 0;


export async function keyboard_down(e)
{

    if(e.key == 'd')
    {
        active = 1;
    }
    if(active ) {
        var data = await AppController.get_data();
        switch (e.key) {
            case "ArrowUp":
                if(data['active_y'] > 0) {
                    var new_y = data['active_y'] - 1;
                    fetch(new URL("/set_active_cell/" + data['active_matrix'] + "/" + new_y + "/" + data['active_x'] + "/" + 0, server))
                        .then(res => res.json())
                        .then(res => {

                                ReactDOM.render(
                                    <React.StrictMode>
                                        <CalcDisplay Data={res}/>
                                    </React.StrictMode>,
                                    document.getElementById('calc_display')
                                );
                            var el = document.getElementById("celltrue");
                            el.focus();
                                el.setSelectionRange(res['caret'], res['caret']);
                            }, (err) => {
                                console.log(err);
                            }
                        );
                }
                break;
            case "ArrowRight":

                if(data['active_x'] < data['all_matrix'][data['active_matrix']][data['active_y']].length -1) {
                    var new_x = data['active_x'] + 1;
                    fetch(new URL("/set_active_cell/" + data['active_matrix'] + "/" + data['active_y'] + "/" + new_x + "/" + 0, server))
                        .then(res => res.json())
                        .then(res => {

                                ReactDOM.render(
                                    <React.StrictMode>
                                        <CalcDisplay Data={res}/>
                                    </React.StrictMode>,
                                    document.getElementById('calc_display')
                                );
                            var el = document.getElementById("celltrue");
                            el.focus();
                                el.setSelectionRange(res['caret'], res['caret']);
                            }, (err) => {
                                console.log(err);
                            }
                        );
                }
                break;
            case "ArrowDown":
                if(data['active_y'] < data['all_matrix'][data['active_matrix']].length -1) {
                    var new_y = data['active_y'] + 1;
                    fetch(new URL("/set_active_cell/" + data['active_matrix'] + "/" + new_y + "/" + data['active_x'] + "/" + 0, server))
                        .then(res => res.json())
                        .then(res => {

                                ReactDOM.render(
                                    <React.StrictMode>
                                        <CalcDisplay Data={res}/>
                                    </React.StrictMode>,
                                    document.getElementById('calc_display')
                                );
                            var el = document.getElementById("celltrue");
                            el.focus();
                                el.setSelectionRange(res['caret'], res['caret']);
                            }, (err) => {
                                console.log(err);
                            }
                        );
                }
                break;
            case "ArrowLeft":
                if(data['active_x'] > 0) {
                    var new_x = data['active_x'] - 1;
                    fetch(new URL("/set_active_cell/" + data['active_matrix'] + "/" + data['active_y'] + "/" + new_x + "/" + 0, server))
                        .then(res => res.json())
                        .then(res => {

                                ReactDOM.render(
                                    <React.StrictMode>
                                        <CalcDisplay Data={res}/>
                                    </React.StrictMode>,
                                    document.getElementById('calc_display')
                                );
                            var el = document.getElementById("celltrue");
                            el.focus();
                                el.setSelectionRange(res['caret'], res['caret']);
                            }, (err) => {
                                console.log(err);
                            }
                        );

                }
                break;
            case "+":
                await CalcController.add_oper("+");

                break;
            case "-":

                await CalcController.add_oper("-");

                break;
            case "*":

                await CalcController.add_oper("*");
                break;

            case "Delete":
                await CalcController.del();
                break;

            case "m":
                await CalcController.add_matrix();
                break;
            case "Backspace":
                fetch(new URL("/del_oper", server))
                    .then(res => res.json())
                    .then(res => {

                            ReactDOM.render(
                                <React.StrictMode>
                                    <CalcDisplay Data={res}/>
                                </React.StrictMode>,
                                document.getElementById('calc_display')
                            );
                        var el = document.getElementById("celltrue");
                        el.focus();
                            el.setSelectionRange(res['caret'], res['caret']);
                        }, (err) => {
                            console.log(err);
                        }
                    );
                break;

            default:
                break;
        }

    }
}

export async function keyboard_up(e)
{
    if(e.key == 'd')
    {
        active = 0;
    }
}

