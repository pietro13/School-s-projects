import ReactDOM from "react-dom";
import React from "react";


import * as AppController from "./AppController";
import CalcPanel from "../View/CalcPanel";
import CalcDisplay from "../View/CalcDisplay";
import App from "../View/App";


var server = 'http://127.0.0.1:9000';


//pohyb panelu
export function move_panel(e)
{

    var element = document.getElementById("Panel");


    element.onmousemove=(ev) =>{
        ReactDOM.render(

            <CalcPanel className="calc-grid" x={ ev.pageX - 200 } y={  ev.pageY - 625}/>
        ,
        document.getElementById('Panel'))};

    element.onmouseup = () => {
        element.onmousemove = () => {};
    }



}



// pridanie matice
export async function add_matrix()
{




            fetch(new URL("/add_new_matrix", server))
                .then(res => res.json())
                .then(res => {
                         ReactDOM.render(
                        <React.StrictMode>
                            <CalcDisplay Data = {res}/>
                        </React.StrictMode>,
                        document.getElementById('calc_display')
                    );
                    var el = document.getElementById("celltrue");
                    el.focus();
                    el.setSelectionRange(res['caret'], res['caret']);
                    }, (err) => {
                        console.log(err);
                    }
                );

}

//pridanie operacie
export async function add_oper(oper)
{



        fetch(new URL("/add_new_oper/" + oper, server))
            .then(res => res.json())
            .then(res => {
                    ReactDOM.render(
                        <React.StrictMode>
                            <CalcDisplay Data = {res}/>
                        </React.StrictMode>,
                        document.getElementById('calc_display')
                    );

                }, (err) => {
                    console.log(err);
                }
            );


}

//odstranenie matice
export async function del()
{

                fetch(new URL("/del_matrix", server))
                    .then(res => res.json())
                    .then(res => {
                            ReactDOM.render(
                                <React.StrictMode>
                                    <CalcDisplay Data={res}/>
                                </React.StrictMode>,
                                document.getElementById('calc_display')
                            );
                        }, (err) => {
                            console.log(err);
                        }
                    );


}

// inspiracia z https://stackoverflow.com/questions/33855641/copy-output-of-a-javascript-variable-to-the-clipboard?fbclid=IwAR0ncq7rO_PcZICNKb2TZ47RBL241kaUGQb_vp8quu2ER0asLn3vHer_-ss
//copirovanie matice do clipboardu
export async function copy()
{
    var data = await AppController.get_data();
    var newmatrix = "";
    var oldmatrix = data['all_matrix'][data['active_matrix']]
    for( var i = 0; i< oldmatrix.length; i++)
    {
        for(var j = 0; j<oldmatrix[0].length; j++)
        {
            if(oldmatrix[i][j])
                newmatrix += oldmatrix[i][j] + ',';
            else
                newmatrix += '0,';
        }
        newmatrix = newmatrix.slice(0,-1) + '\r\n';

    }
    newmatrix = newmatrix.slice(0,-1);
    var dummy = document.createElement("textarea");
    document.body.appendChild(dummy);

    dummy.value = newmatrix;
    dummy.select();
    document.execCommand("copy");
    document.body.removeChild(dummy);


}
//transponovanie matice
export async function transpon()
{



        fetch(new URL("/trans_matrix", server))
            .then(res => res.json())
            .then(res => {
                    ReactDOM.render(
                        <React.StrictMode>
                            <CalcDisplay Data={res}/>
                        </React.StrictMode>,
                        document.getElementById('calc_display')
                    );
                }, (err) => {
                    console.log(err);
                }
            );


}
//drop matice
export async function droptoMatrix(e)
{
    //spracovanie vstupu z textu na array
    await e.preventDefault();
    var textData = e.dataTransfer.getData('text');
    var array = [];
    var line = textData.split('\r\n');
    for( var i = 0; i < line.length && i < 10; i++)
    {
        var column_array = [];
        var column = line[i].split(",");
        for(var j = 0 ; j < column.length && j < 10;j++)
        {
            if(((column[j].match("^-?[0-9]?$") != null ||
                column[j].match("^-?0\\.[0-9]*$") != null ||
                column[j].match("^-?[1-9][0-9]*$") != null ||
                column[j].match("^-?[1-9][0-9]*\\.[0-9]*$") != null ) && !false) ||
                (column[j].match("^[0-9]?$") != null ||
                    column[j].match("^0\\.[0-9]*$") != null ||
                    column[j].match("^[1-9][0-9]*$") != null ||
                    column[j].match("^[1-9][0-9]*\\.[0-9]*$") != null ) ) {
                column_array.push(column[j]);
            }
            else
            {
                column_array.push('');
            }
        }
        array.push(column_array);
    }
    array = JSON.stringify(array);

    fetch(new URL("/drop_to_matrix/" + array, server))
        .then(res => res.json())
        .then(res => {
                ReactDOM.render(
                    <React.StrictMode>
                        <CalcDisplay Data={res}/>
                    </React.StrictMode>,
                    document.getElementById('calc_display')
                );
            }, (err) => {
                console.log(err);
            }
        );

}
// ziskanie vysledku
export async function result()
{
    fetch(new URL("/result/", server))
        .then(res => res.json())
        .then((res) => {
            ReactDOM.render(
            <React.StrictMode>
                <App Data={res} />
            </React.StrictMode>,
                document.getElementById('root'))}, (err) => {console.log(err);});
}