
import React from 'react'
import * as MatrixController from "../Controller/MatrixController"





class RangeSlider extends React.Component {
    constructor (props) {
        super(props);

    }




    //////////////////////////////////////////////////////VIEW/////////////////////////////////////////

    render () {

        var value;
        var styl;
        if(this.props.type === 1)
        {
              value = this.props.matrix[0].length-1;
              styl = {};
            return (
                <div  >

                    <input
                        className="range-slide"
                        name="range"
                        type="range"
                        min="0"
                        max="9"
                        value={value}
                        step="1"
                        onChange={(e) => MatrixController.change_columns(e.target.value,e.target.value != value)}
                        style={styl}

                    />

                </div>
            );
        }
        else {
            value = this.props.matrix.length - 1;
            styl = {transform: "rotate(90deg)"};
            return (
                <div  >

                    <input
                        className="range-slide"
                        name="range"
                        type="range"
                        min="0"
                        max="9"
                        value={value}
                        step="1"
                        onChange={(e) => MatrixController.change_rows(e.target.value,e.target.value != value)}
                        style={styl}

                    />

                </div>
            );
        }

    }
}


export default RangeSlider;