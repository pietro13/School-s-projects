import React from 'react'
import Matrix from './react-matrix'
import RangeSlider from "./Slider";
import * as CalcController from "../Controller/CalcController"







class CalcDisplay extends React.Component{

    constructor(props) {
        super(props);
    }



    render()
    {

        console.log(this.props.Data);

        var j = 0;

        return (
            <div className="matrix-display" >
                {this.props.Data['all_matrix'].map((row, i) => (

                    <span key={i} onClick={()=>console.log(i) } >
                            <span className="padding_left align_start">
                                {(this.props.Data['active_matrix'] === i) && <input className="no_cursor" key={i+ "p1"} style={{ width: "60px" , height: "30px" , 'text-align' : 'center' }} readOnly={false}
                                                                            onDrop={(e) => CalcController.droptoMatrix(e)}
                                                                        value={"DROP"}  /> }
                                {(this.props.Data['active_matrix'] === i) && <button className="buttons2" onClick={() => CalcController.copy()} > copy </button>}
                                {(this.props.Data['active_matrix'] === i) && <button className="buttons2" onClick={() => CalcController.transpon()}> transpon </button>}
                                {(this.props.Data['active_matrix'] === i) && <button className="buttons2" onClick={() => CalcController.del()} > delete </button>}
                                {(this.props.Data['active_matrix'] === i) && <RangeSlider key={i + "p2"} type = {1} matrix={this.props.Data['all_matrix'][i]} />}
                            </span>
                            <span className="padding_top align_center">
                                <span  className="align_start">

                                    {(this.props.Data['active_matrix'] === i) && <RangeSlider key={i+ "p3"} type = {2} matrix={this.props.Data['all_matrix'][i]} />}
                                </span>

                                <span  className="matrix-output" >

                                    <Matrix matrix={this.props.Data['all_matrix'][i]} Data={this.props.Data}
                                            index={j++} key={i + "p4"} readonly={false}/>



                                    <span style={{padding: '20px'}}>
                                    {this.props.Data['all_oper'][i] &&
                                    <input className="oper" key={i + "p5"} value={this.props.Data['all_oper'][i]}  style={{width: 20,

                                        margin: '4px 0',
                                        'font-size': '25px',
                                        padding: '4px',
                                        textAlign: 'center',
                                    }}/>
                                    }
                                </span></span>
                            </span>
                        </span>
                ))}



            </div>

        );
    }
}

export default CalcDisplay;