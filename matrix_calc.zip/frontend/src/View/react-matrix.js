/**
 * prebrate od:
 *  Olav Lindekleiv http://lindekleiv.com/
 *  upravene pre vlasne pouzitie
 */

import React from 'react'
import * as MatrixController from "../Controller/MatrixController"
import * as KeyboardController from "../Controller/KeyboardController"

class MatrixCell extends React.Component {
	constructor(props) {
		super(props);
		

	}

//////////////////////////////////////////////////////////////////Matrix Cell view
	render() {
		var classe = "Matrix_cell_default";

		if(this.props.active) {classe = "Matrix_cell_active";}

		console.log(this.props.z + "|" +this.props.value.length)

		if(this.props.readonly)
		{
			return (
			<input className={classe}
				   id={this.props.active ? "cell" + this.props.active : "cell" + this.props.x + this.props.y + this.props.z}
				   type="text" style={ {"width": ('' + this.props.value).length * 8 , } }
				   value={this.props.value} placeholder="0" readOnly={this.props.readonly} autocomplete="off" />)

		}
		else {
			return (
				<input className={classe}
					   id={this.props.active ? "cell" + this.props.active : "cell" + this.props.x + this.props.y + this.props.z}
					   type="text" style={this.props.active ? {"width": this.props.value.length * 8} : {"width": 30}}
					   value={this.props.value} placeholder="0" readOnly={this.props.readonly} autocomplete="off"
					   onClick={(e) => MatrixController.active_cell(e, this.props.z, this.props.y, this.props.x)}
					   onKeyDown={(event) => KeyboardController.keyboard_down(event)}
					   onKeyUp={(event) => KeyboardController.keyboard_up(event)}
					   onChange={(e) => MatrixController.set_value_cell(e, this.props.z, this.props.y, this.props.x)}
				/>
			);
		}
	}
};

////////////////////////////////////////////////////////Matrix View

class Matrix extends React.Component {
	constructor(props) {
		super(props);

	}



	render() {
		console.log(this.props.index + "|" + this.props.readonly)
		var columns = this.props.matrix[0].map(function(columnValues, x) {
			var y = 0;
			var column = this.props.matrix.map(function(value, y) {
				var active = this.props.index == this.props.Data['active_matrix'] && x == this.props.Data['active_x'] && y == this.props.Data['active_y'];
				var cell = <MatrixCell key={x+'-'+y} value={this.props.matrix[y][x]} matrix={this} z={this.props.index} Data={this.props.Data} x={x} y={y}  active={active} readonly={this.props.readonly} />

				return cell;
			}, this)

			var columnStyle = {
				float: 'left',
				display: 'relative',
				'justify-content': 'center',

				'align-items': 'right',
				overflow: 'auto',
				padding: '0 2px',
			}

			var col = <div key={y} style={columnStyle}>{column}</div>
			return col;
			
		}, this)

		return (
			<div style={{
				overflow: 'auto',
				display: 'inline-flex',
				borderLeft: '2px solid #333',
				borderRight: '2px solid #333',
				padding: '2px',
				borderRadius: '4px'
			}}>
				{columns}
			</div>
		);
	};
}



export default Matrix;