import React from 'react'
import '../App.css';
import Calc from './Calc';

import * as AppController from "../Controller/AppController";


import Matrix from "./react-matrix";





class App extends React.Component {



/////////////////////////////// VIEW ////////////////////////////////////////////////////
 render(){

     return (
         <div className="App">
             <div className="bar">
                 <div className="bar" id="koment">
                    <input className="buttons" type="button" value="Pridaj koment" />
                </div>
             </div>
             <div className="Name">
                 <text className="definition-text"> Názov:</text>
                 <input type="text" defaultValue={this.props.Data['name']} style={{fontSize: 30}} onChange={(e) => AppController.add_name(e)}/>
             </div>
             <div className="declaration">
                 <text className="definition-text"> Popis:</text>
                 <textarea defaultValue={this.props.Data['instruct'] } onChange={(e) => AppController.add_instruct(e)}/>
             </div>
             {/*maticovy retazec*/}
             <div id="calc">
                 <Calc  Data={this.props.Data} />
             </div>
             {/*vysledok*/}
             {this.props.Data['result'][0] &&
            <div className="result" ><text className="definition-text"> Vysledok:</text>
                   <Matrix matrix={this.props.Data['result'][0]} Data={this.props.Data} index={-5} key={"d9"} readonly={true}/>
             </div>}
             {/*postup*/}
             {this.props.Data['process'][0] &&
             <div className="process" ><text className="definition-text"> Postup:</text>
                 {this.props.Data['process'].map((row, i) => (

                     <div className="process_line" key={i} >
                         {/*poradie postupu*/}
                         <input className="oper" key={i + "p5"} value={i + 1 + ":"}  style={{width: 20,

                             margin: '4px 0',
                             'font-size': '25px',
                             padding: '4px',
                             textAlign: 'center',
                         }}/>

                         {/*matica*/}
                            <Matrix matrix={this.props.Data['process'][i][0]} Data={this.props.Data} index={-10 - i} key={i + "d1"} readonly={true} />
                         {/*operacia*/}
                            <input className="oper" key={i + "p5"} value={this.props.Data['process'][i][1]}  style={{width: 20,

                         margin: '4px 0',
                         'font-size': '25px',
                         padding: '4px',
                         textAlign: 'center',
                     }}/>
                         {/*matica*/}
                            <Matrix matrix={this.props.Data['process'][i][2]} Data={this.props.Data} index={-11 - i} key={i + "d2"} readonly={true}/>
                         {/*rovnost*/}
                            <input className="oper" key={i + "p5"} value="="  style={{width: 20,

                             margin: '4px 0',
                             'font-size': '25px',
                             padding: '4px',
                             textAlign: 'center',
                         }}/>
                         {/*vysledok postupu*/}
                            <Matrix matrix={this.props.Data['process'][i][3]} Data={this.props.Data} index={-12 - i} key={i + "d3"} readonly={true}/>

                        </div>
                 ))}



             </div>}



         </div>
     );
 }
}

export default App;
