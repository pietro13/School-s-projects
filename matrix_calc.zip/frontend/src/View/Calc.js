import React from 'react'
import CalcPanel from "./CalcPanel";

import CalcDisplay from "./CalcDisplay";

class Calc extends React.Component{

    constructor(props) {
        super(props);
    }




///////////////////////////////////////////VIEW////////////////////////////////////////////////////////////////////////
    render(){

        return(
            <span >
                <span id="calc_display" >
                    <CalcDisplay Data = {this.props.Data}/>
                </span>
                <div id="Panel">
                    <CalcPanel className="calc-grid" x={0} y={0}/>
                </div>
            </span>
        )
    }
}

export default Calc;