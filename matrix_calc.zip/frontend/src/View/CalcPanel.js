import React from 'react';
import CalcButton from "./CalcButton";

import * as CalcController from "../Controller/CalcController";
import  * as MatrixController from "../Controller/MatrixController"

function CalcPanel (props)
{

    const buttons =[
        {text: "7", handler: ()=> MatrixController.set_value_cell_panel("7")},
        {text: "8", handler: ()=> MatrixController.set_value_cell_panel("8")},
        {text: "9", handler: ()=> MatrixController.set_value_cell_panel("9")},
        {text: "*", handler: ()=> CalcController.add_oper("*")},
        {text: "4", handler: ()=> MatrixController.set_value_cell_panel("4")},
        {text: "5", handler: ()=> MatrixController.set_value_cell_panel("5")},
        {text: "6", handler: ()=> MatrixController.set_value_cell_panel("6")},
        {text: "-", handler: ()=> CalcController.add_oper("-")},
        {text: "1", handler: ()=> MatrixController.set_value_cell_panel("1")},
        {text: "2", handler: ()=> MatrixController.set_value_cell_panel("2")},
        {text: "3", handler: ()=> MatrixController.set_value_cell_panel("3")},
        {text: "+", handler: ()=> CalcController.add_oper("+")},
        {text: ".", handler: ()=> MatrixController.set_value_cell_panel(".")},
        {text: "0", handler: ()=> MatrixController.set_value_cell_panel("0")},
        {text: "C", handler: ()=> MatrixController.del_value_cell_panel()},
        {text: "[-]", handler: ()=> MatrixController.set_value_cell_panel("-")},
        {text: "=", handler: ()=> CalcController.result()},
        {text: "Vlož maticu", handler: ()=> CalcController.add_matrix()}
    ];
    const calc_buttons= buttons.map((value,index) => {
        return <CalcButton
            caption={value.text}
            onClick={value.handler}
        />
    });
    console.log(props.y);
    return(
        <div  className="Calc-buttons" style={{ "margin-left" : props.x, "margin-top" : props.y }} >

        <div className="movecalc" onMouseDown={(event) => CalcController.move_panel(event) }> Zmeň polohu</div>
        <div className="calc-grid">
            {calc_buttons}
        </div>
    </div>


    )
}
export default CalcPanel;