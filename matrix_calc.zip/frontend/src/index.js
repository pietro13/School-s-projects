import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './View/App';
import reportWebVitals from './reportWebVitals';
import * as AppController from "./Controller/AppController";


fetch(new URL("/get_data",'http://127.0.0.1:9000'))
    .then(res => res.json())
    .then( data =>{ ReactDOM.render(
        <React.StrictMode>
            <App Data={data} />
        </React.StrictMode>,
        document.getElementById('root'))}, (err) => {console.log(err);});




// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
